#!/bin/bash

cat $1 | httpx -silent -threads $2 -path '/.git/config' -match-string '[core]' -o vulns.txt
sed -i 's/\/config$//g' vulns.txt
